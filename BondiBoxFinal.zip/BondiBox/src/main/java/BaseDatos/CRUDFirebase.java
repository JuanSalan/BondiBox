package BaseDatos;

import Modelos.*;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.Query;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.cloud.firestore.WriteResult;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


public class CRUDFirebase {
    
    //Lista de correo y contraseña de la collección "Usuarios"
    private ObservableList<IngresoUsuarios> ListaUsuarios = FXCollections.observableArrayList();
    private ObservableList<Contraseñas> ListaContraseñas = FXCollections.observableArrayList();
    private IngresoUsuarios ingresousuarios;
    private Contraseñas ingresocontraseñas;
    public ObservableList<IngresoUsuarios> getListaUsuarios(){
        return ListaUsuarios;
    }
    public ObservableList<Contraseñas> getListaContraseñases(){
        return ListaContraseñas;
    }
    public static Firestore bd ;
    public CRUDFirebase(){
        ConexionFirebase conexionfirebase = new ConexionFirebase();
        bd = conexionfirebase.iniciarFirebase();
    }
    private  boolean key;
    public  List<Productos> Listaproductos =new ArrayList();
    public  List<List<String>> Listainformes =new ArrayList();
    public  List<List<String>> Listapro =new ArrayList();

    private Productos producto;

    public List<Productos> getListaproductos() {
        return Listaproductos;
    }
    public List<List<String>> getListainformes() {
        return Listainformes;
    }
    public List<List<String>> getListapro() {
        return Listapro;
    }
    
    
    public boolean agregarFirebaseproducto(Productos producto){
        // Create a Map to store the data we want to set
        Map<String, Object> docProducto = new HashMap<>();
        //docProducto.put("ID",producto.getID());
        docProducto.put("Nombre",producto.getNombre());
        docProducto.put("Categoria",producto.getCategoria());
        docProducto.put("Descripcion",producto.getDescripcion());
        docProducto.put("Precio",producto.getPrecio());
        docProducto.put("Cantidad",producto.getCantidad());
        // Add a new document (asynchronously) in collection "cities" with id "LA"
        ApiFuture<WriteResult> future = bd.collection("productos").document(UUID.randomUUID().toString()).set(docProducto);
        try {
            System.out.println("Update time : " + future.get().getUpdateTime());
            key = true;
        } catch (InterruptedException |ExecutionException ex) {
          ex.printStackTrace();
        }
        return key;
    }
    public   boolean agregarFirebaseinforme(Informes informes){
        // Create a Map to store the data we want to set
        Map<String, Object> docInforme = new HashMap<>();
        //docProducto.put("ID",producto.getID());
        docInforme.put("Nombre",informes.getNombre());
        docInforme.put("Lugar",informes.getLugar());
        docInforme.put("Producto",informes.getProducto());
        
        // Add a new document (asynchronously) in collection "cities" with id "LA"
        ApiFuture<WriteResult> future = bd.collection("Informes").document(UUID.randomUUID().toString()).set(docInforme);
        try {
            System.out.println("Update time : " + future.get().getUpdateTime());
            key = true;
        } catch (InterruptedException |ExecutionException ex) {
          ex.printStackTrace();
        }
        return key;
    }
    public List<List<String>> leerFirebaseInforme() throws InterruptedException, ExecutionException{
        //asynchronously retrieve all documents
        ApiFuture<QuerySnapshot> future = bd.collection("Informes").get();
        // future.get() blocks on response
        List<QueryDocumentSnapshot> documents;
            documents = future.get().getDocuments();
            if (!documents.isEmpty()) {
                System.out.println("Leyendo datos");
                for (QueryDocumentSnapshot document : documents) {
                    Informes informe  = new Informes(document.getData().get("Nombre").toString(), document.getData().get("Lugar").toString(), document.getData().get("Producto").toString(), document.getData().get("Fecha").toString());
                    ArrayList listainfo = new ArrayList();
                     listainfo.add(informe.getNombre());
                     listainfo.add(informe.getLugar());
                     listainfo.add(informe.getProducto());
                     listainfo.add(informe.getFecha());
                     Listainformes.add( listainfo);   
                }  
            }    
            else{
                System.out.println("No hay datos");   
            }
        return  Listainformes; 
    }
    public List<List<String>> leerFirebaseProducto() throws InterruptedException, ExecutionException{
        //asynchronously retrieve all documents
        ApiFuture<QuerySnapshot> future = bd.collection("productos").get();
        // future.get() blocks on response
        List<QueryDocumentSnapshot> documents;
            documents = future.get().getDocuments();
            if (!documents.isEmpty()) {
                System.out.println("Leyendo datos");
                for (QueryDocumentSnapshot document : documents) {
                    Productos producto = new Productos(document.getData().get("Nombre").toString(), document.getData().get("Categoria").toString(), document.getData().get("Descripcion").toString(), Double.parseDouble(document.getData().get("Precio").toString()),Integer.parseInt(document.getData().get("Cantidad").toString()));
                    ArrayList listapro = new ArrayList();
                    listapro.add(producto.getNombre());
                    listapro.add(producto.getCategoria());
                    listapro.add(producto.getDescripcion());
                    listapro.add(producto.getPrecio());
                    listapro.add(producto.getCantidad());
                    Listapro.add(listapro);   
                }  
            }    
            else{
                System.out.println("No hay datos");   
            }
        return  Listapro; 
    }
    public boolean leerFirebaseproducto(){
        //asynchronously retrieve all documents
        ApiFuture<QuerySnapshot> future = bd.collection("productos").get();
        // future.get() blocks on response
        List<QueryDocumentSnapshot> documents;
        try {
            documents = future.get().getDocuments();
            if (!documents.isEmpty()) {
                
                System.out.println("Leyendo datos");
                for (QueryDocumentSnapshot document : documents) {
                    System.out.println(document.getId() + " => " + document.getData().get("Nombre")+" "+document.getData().get("Categoría")+" "+document.getData().get("Descripción")+" "+document.getData().get("Precio")+" "+document.getData().get("Cantidad"));
                    producto = new Productos(document.getData().get("Nombre").toString(), document.getData().get("Categoría").toString(), document.getData().get("Descripción").toString(), Double.parseDouble(document.getData().get("Precio").toString()),Integer.parseInt(document.getData().get("Cantidad").toString()));
                    Listaproductos.add(producto);
                }
            }    
            else{
                System.out.println("No hay datos");
                    
            }
            
            key = true;
            
            
        } catch (InterruptedException | ExecutionException ex) {
            ex.printStackTrace();
        }
        
    return key;
    }
    
    public void deleteDocument(String Coleccion, String Documento) throws Exception {
        
        ApiFuture<WriteResult> writeResult = bd.collection(Coleccion).document(Documento).delete();
        System.out.println("Update time : " + writeResult.get().getUpdateTime());
    } 
    public boolean  getDocument(String Coleccion, String Documento) throws InterruptedException, ExecutionException{
    // [START fs_get_doc_as_map]
    // [START firestore_data_get_as_map]
        DocumentReference docRef = bd.collection(Coleccion).document(Documento);
    // asynchronously retrieve the document
        ApiFuture<DocumentSnapshot> future = docRef.get();
    // ...
    // future.get() blocks on response
        DocumentSnapshot document = future.get();
        if (document.exists()) {
          key = true;
          
        } else {
          System.out.println("No such document!");
        }
        return key;
    
  }
    public  ArrayList  getDocument(String Coleccion, String Documento,boolean a) throws InterruptedException, ExecutionException{
     DocumentReference docRef = bd.collection(Coleccion).document(Documento);
    // asynchronously retrieve the document
    ApiFuture<DocumentSnapshot> future = docRef.get();
    // ...
    // future.get() blocks on response
    DocumentSnapshot document = future.get();
    if (document.exists()) {
        
      System.out.println("Document data: " + document.getData());
            ArrayList lista = new ArrayList();
            lista.add(document.getData().get("Nombre"));
            lista.add(document.getData().get("Categoria"));
            lista.add(document.getData().get("Descripcion"));
            lista.add(document.getData().get("Precio"));
            lista.add(document.getData().get("Cantidad"));
            return lista;
    } else {
        System.out.println("No such document!");
        ArrayList lista = new ArrayList();
        return lista ;
    }
    }
    
    public boolean agregarUsuarios(Usuarios Registro){
        
        Map<String, Object> Usuarios = new HashMap<>();
        //docProducto.put("ID",producto.getID());
        Usuarios.put("Nombre",Registro.getNombre());
        Usuarios.put("Correo",Registro.getCorreo());
        Usuarios.put("Usuario",Registro.getUsuario());
        Usuarios.put("Contraseña",Registro.getContraseña());
        Usuarios.put("Pais",Registro.getPais());
        Usuarios.put("Rol",Registro.getRol());
        // Add a new document (asynchronously) in collection "Usuarios" with id "Random"
        ApiFuture<WriteResult> future = bd.collection("Usuarios").document(UUID.randomUUID().toString()).set(Usuarios);
        
        try {
            System.out.println("Update time : " + future.get().getUpdateTime());
            key = true;
        } catch (InterruptedException |ExecutionException ex) {
          ex.printStackTrace();
        }
        
        return key;        
    }
    public boolean leerFirebaseUsuarios(IngresoUsuarios Registrados) {

        //asynchronously retrieve all documents
        ApiFuture<QuerySnapshot> future = bd.collection("Usuarios").get();
        // future.get() blocks on response

        List<QueryDocumentSnapshot> documents;
        try {
            documents = future.get().getDocuments();
            if (!documents.isEmpty()) {

                System.out.println("Leyendo datos");
                for (QueryDocumentSnapshot document : documents) {
                    System.out.println(document.getId() + " => " + document.getData().get("Correo") + " --- " + document.getData().get("Contraseña") + " --- " + document.getData().get("Rol"));
                    ingresousuarios = new IngresoUsuarios(String.valueOf(document.getData().get("Correo")), document.getData().get("Contraseña").toString(), document.getData().get("Rol").toString());
                    ListaUsuarios.add(ingresousuarios);
                }
            } else {
                System.out.println("No hay datos registrados");
            }

            key = true;

        } catch (InterruptedException | ExecutionException ex) {
            ex.printStackTrace();
        }

        return key;
    }
    public boolean leerFirebaseContraseña(Contraseñas Registrados) {

        //asynchronously retrieve all documents
        ApiFuture<QuerySnapshot> future = bd.collection("Usuarios").get();
        // future.get() blocks on response

        List<QueryDocumentSnapshot> documents;
        try {
            documents = future.get().getDocuments();
            if (!documents.isEmpty()) {

                System.out.println("Leyendo datos");
                for (QueryDocumentSnapshot document : documents) {
                    System.out.println(document.getId() + " => " + document.getData().get("Usuario") + " --- " + document.getData().get("Correo") + " --- " + document.getData().get("Pais"));
                    ingresocontraseñas = new Contraseñas(String.valueOf(document.getData().get("Usuario")), document.getData().get("Correo").toString(), document.getData().get("Pais").toString());
                    ListaContraseñas.add(ingresocontraseñas);
                }
            } else {
                System.out.println("No hay datos registrados");
            }

            key = true;

        } catch (InterruptedException | ExecutionException ex) {
            ex.printStackTrace();
        }

        return key;
    }
    public void Actualizarcontraseña( String Correo, String Contraseña) throws InterruptedException, ExecutionException{
        CollectionReference usuarios = bd.collection("Usuarios");
        Query query = usuarios.whereEqualTo("Correo", Correo);
        ApiFuture<QuerySnapshot> querySnapshot = query.get();
        for (DocumentSnapshot document : querySnapshot.get().getDocuments()) {
            
            DocumentReference docRef = bd.collection("Usuarios").document(document.getId());
            ApiFuture<WriteResult> future = docRef.update("Contraseña",Contraseña);
        }

    // (async) Update one field
        
    }
}

