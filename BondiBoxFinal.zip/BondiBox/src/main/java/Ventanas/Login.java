/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

import BaseDatos.CRUDFirebase;
import Modelos.*;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


/**
 *
 * @author N
 */
public class Login extends javax.swing.JFrame {
    
    int xMouse,yMouse;
    private ObservableList<IngresoUsuarios> ListaUsuarios = FXCollections.observableArrayList();
    
    
    
    /**
     * Creates new form Login
     */
    public static final CRUDFirebase cRUDFirebase = new CRUDFirebase();
    public Login() {
        initComponents();
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txtContraseña = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();
        txtCorreo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lblRegistro1 = new javax.swing.JButton();
        jLabel1_nombre = new javax.swing.JLabel();
        lblRegistro2 = new javax.swing.JButton();
        btnIniciar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        lblAviso = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(61, 126, 182));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 190, 600));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanel3MouseDragged(evt);
            }
        });
        jPanel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel3MousePressed(evt);
            }
        });
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        jLabel1.setText(" X");
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 0, 30, 40));
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 430, -1, 170));

        jLabel10.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        jLabel10.setText("  X");
        jLabel10.setToolTipText("");
        jLabel10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 0, 40, 40));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Arial Narrow", 1, 36)); // NOI18N
        jLabel4.setText("Iniciar Sesión");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 70, 210, -1));

        txtContraseña.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        txtContraseña.setForeground(new java.awt.Color(204, 204, 204));
        txtContraseña.setText("********");
        txtContraseña.setBorder(null);
        txtContraseña.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtContraseñaMouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtContraseñaMousePressed(evt);
            }
        });
        txtContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContraseñaActionPerformed(evt);
            }
        });
        jPanel1.add(txtContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 330, 280, 30));

        jLabel2.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel2.setText("Contraseña");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 280, -1, -1));

        txtCorreo.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        txtCorreo.setForeground(new java.awt.Color(204, 204, 204));
        txtCorreo.setText("Ingrese su correo");
        txtCorreo.setBorder(null);
        txtCorreo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtCorreoMousePressed(evt);
            }
        });
        txtCorreo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoActionPerformed(evt);
            }
        });
        jPanel1.add(txtCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, 280, 30));

        jLabel3.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel3.setText("Correo");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 190, 50, -1));

        jLabel5.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel5.setText("¿No tienes cuenta? Registrate ");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel5MouseExited(evt);
            }
        });
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, -1, -1));

        lblRegistro1.setBackground(new java.awt.Color(255, 255, 255));
        lblRegistro1.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        lblRegistro1.setText("aquí");
        lblRegistro1.setBorder(null);
        lblRegistro1.setBorderPainted(false);
        lblRegistro1.setContentAreaFilled(false);
        lblRegistro1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRegistro1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblRegistro1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblRegistro1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblRegistro1MouseExited(evt);
            }
        });
        lblRegistro1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblRegistro1ActionPerformed(evt);
            }
        });
        jPanel1.add(lblRegistro1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 130, -1, -1));

        jLabel1_nombre.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        jLabel1_nombre.setText("BondiBox");
        jPanel1.add(jLabel1_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 100, 20));

        lblRegistro2.setBackground(new java.awt.Color(255, 255, 255));
        lblRegistro2.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        lblRegistro2.setText("Olvidé mi contraseña");
        lblRegistro2.setBorder(null);
        lblRegistro2.setContentAreaFilled(false);
        lblRegistro2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRegistro2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblRegistro2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblRegistro2MouseExited(evt);
            }
        });
        lblRegistro2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblRegistro2ActionPerformed(evt);
            }
        });
        jPanel1.add(lblRegistro2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 470, 130, 37));

        btnIniciar.setBackground(new java.awt.Color(61, 126, 182));
        btnIniciar.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btnIniciar.setForeground(new java.awt.Color(255, 255, 255));
        btnIniciar.setText("Iniciar");
        btnIniciar.setBorder(null);
        btnIniciar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarActionPerformed(evt);
            }
        });
        jPanel1.add(btnIniciar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 420, 80, 30));

        btnCancelar.setBackground(new java.awt.Color(61, 126, 182));
        btnCancelar.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btnCancelar.setForeground(new java.awt.Color(255, 255, 255));
        btnCancelar.setText("Cancelar");
        btnCancelar.setBorder(null);
        btnCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 420, 80, 30));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, 280, 20));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 360, 280, 20));

        lblAviso.setFont(new java.awt.Font("Arial Narrow", 0, 12)); // NOI18N
        lblAviso.setForeground(new java.awt.Color(255, 0, 0));
        jPanel1.add(lblAviso, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 310, 20));

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\KL\\Documents\\NetBeansProjects\\BondiBox\\src\\main\\Resources\\Fondo3.jpg")); // NOI18N
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 360, 150, -1));

        jPanel3.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 50, 610, 530));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 580));

        setSize(new java.awt.Dimension(800, 580));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarActionPerformed
           
        
        String CorreoIngresado = txtCorreo.getText();
        //Obtener texto de jpasswordField
        char[] arrayC = txtContraseña.getPassword();
        String ContraseñaIngresada = new String(arrayC); // ContraseñaIngresada es el texto del jpasswordField
        String RolUsuario = "Administrador";
        
        IngresoUsuarios iu = new IngresoUsuarios(CorreoIngresado, ContraseñaIngresada, RolUsuario);
        
        
        if(cRUDFirebase.leerFirebaseUsuarios(iu)){
            System.out.println("No hubo errores");
            ObservableList<IngresoUsuarios> ListaUsuarios = cRUDFirebase.getListaUsuarios();
            if(ListaUsuarios.size()>0){
                this.ListaUsuarios=ListaUsuarios;
                
                System.out.println(ListaUsuarios);
                
                
                
                //Imprimir correo y contraseña guardados en el ArrayList de la colección Usuarios
                for (int i = 0; i < ListaUsuarios.size(); i++) {
                    System.out.println(ListaUsuarios.get(i).getCorreo().equals(CorreoIngresado) + " *** "+ ListaUsuarios.get(i).getContraseña().equals(ContraseñaIngresada) + " *** "+ ListaUsuarios.get(i).getRol().equals(RolUsuario));
                
                    if(ListaUsuarios.get(i).getCorreo().equals(CorreoIngresado) == true & ListaUsuarios.get(i).getContraseña().equals(ContraseñaIngresada) == true){
                        System.out.println("Registrado");
                        
                        if(ListaUsuarios.get(i).getRol().equals(RolUsuario) == true){
                        System.out.println("Administrador");
                        Principal p = new Principal();
                        p.setVisible(true);
                        setVisible(false);
                        }else{
                            Empleado e = new Empleado();
                            e.setVisible(true);
                            this.setVisible(false);
                        }
                            
                }else{
                        System.out.println("No registrado");
                        lblAviso.setFont(new java.awt.Font("Arial Narrow", 1, 12));
                        lblAviso.setText("Los datos ingresados son incorrectos!");
                        
                    }
                }
            }else{
                System.out.println("Error");
            }
        }
    }//GEN-LAST:event_btnIniciarActionPerformed

    private void txtContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContraseñaActionPerformed

    private void lblRegistro1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblRegistro1ActionPerformed
        // TODO add your handling code here:
        Registro r = new Registro();
        r.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_lblRegistro1ActionPerformed

    private void lblRegistro1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRegistro1MouseExited
        lblRegistro1.setForeground(new java.awt.Color(0,0,0));
    }//GEN-LAST:event_lblRegistro1MouseExited

    private void lblRegistro1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRegistro1MouseEntered
        lblRegistro1.setForeground(new java.awt.Color(61,126,182));
    }//GEN-LAST:event_lblRegistro1MouseEntered

    private void lblRegistro2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblRegistro2ActionPerformed
        Contraseña r = new Contraseña();
        r.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_lblRegistro2ActionPerformed

    private void lblRegistro2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRegistro2MouseExited
        lblRegistro2.setForeground(new java.awt.Color(0,0,0));
    }//GEN-LAST:event_lblRegistro2MouseExited

    private void lblRegistro2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRegistro2MouseEntered
        lblRegistro2.setForeground(new java.awt.Color(61,126,182));
    }//GEN-LAST:event_lblRegistro2MouseEntered

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jPanel3MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel3MouseDragged
        int x=evt.getXOnScreen();
        int y=evt.getYOnScreen();
        this.setLocation(x-xMouse,y-yMouse);
    }//GEN-LAST:event_jPanel3MouseDragged

    private void jPanel3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel3MousePressed
        xMouse=evt.getX();
        yMouse=evt.getY();
    }//GEN-LAST:event_jPanel3MousePressed

    private void txtCorreoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCorreoMousePressed
        if(txtCorreo.getText().equals("Ingrese su correo")){
            txtCorreo.setText("");
            txtCorreo.setForeground(new java.awt.Color(0,0,0));
        }
        if(String.valueOf(txtContraseña.getPassword()).isEmpty()){
            txtContraseña.setText("********");
            txtContraseña.setForeground(new java.awt.Color(204,204,204));   
        }
    }//GEN-LAST:event_txtCorreoMousePressed

    private void txtContraseñaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtContraseñaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContraseñaMouseEntered

    private void txtContraseñaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtContraseñaMousePressed
        if(String.valueOf(txtContraseña.getPassword()).equals("********")){
            txtContraseña.setText("");
            txtContraseña.setForeground(new java.awt.Color(0,0,0));
        }
        if(txtCorreo.getText().isEmpty()){
            txtCorreo.setText("Ingrese su correo");
            txtCorreo.setForeground(new java.awt.Color(204,204,204));
        }
    }//GEN-LAST:event_txtContraseñaMousePressed

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel10MouseClicked

    private void jLabel5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseEntered
        
    }//GEN-LAST:event_jLabel5MouseEntered

    private void jLabel5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseExited
        
    }//GEN-LAST:event_jLabel5MouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnIniciar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel1_nombre;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblAviso;
    private javax.swing.JButton lblRegistro1;
    private javax.swing.JButton lblRegistro2;
    private javax.swing.JPasswordField txtContraseña;
    private javax.swing.JTextField txtCorreo;
    // End of variables declaration//GEN-END:variables

   
}
