/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author N
 */
public class IngresoUsuarios extends RecursiveTreeObject {
    
    private StringProperty Correo, Contraseña, Rol;
    
    public IngresoUsuarios(String Correo, String Contraseña, String Rol){
              
        this.Correo = new SimpleStringProperty(Correo);
        
        this.Contraseña = new SimpleStringProperty(Contraseña);
        
        this.Rol = new SimpleStringProperty(Rol);
               
    }
    
    
    public String getCorreo(){
        return Correo.get();
    }
    public void setCorreo(String Correo){
        this.Correo = new SimpleStringProperty(Correo);
    }
    
    
    public String getContraseña(){
        return Contraseña.get();
    }
    public void setContraseña(String Contraseña){
        this.Contraseña = new SimpleStringProperty(Contraseña);
    }
    
    
    public String getRol(){
        return Rol.get();
    }
    public void setRol(String Rol){
        this.Rol = new SimpleStringProperty(Rol);
    }
    
    
}
