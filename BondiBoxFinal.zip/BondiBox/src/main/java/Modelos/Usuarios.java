
package Modelos;

import com.google.firebase.auth.FirebaseAuth;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.beans.property.SimpleStringProperty;

import javafx.beans.property.StringProperty;

public class Usuarios extends RecursiveTreeObject {
    private StringProperty Nombre, Correo, Usuario, Contraseña, Pais, Rol;
    
    public Usuarios(String Nombre, String Correo, String Usuario, String Contraseña, String Pais, String Rol){
        this.Nombre = new SimpleStringProperty(Nombre);
        this.Correo = new SimpleStringProperty(Correo);
        this.Usuario = new SimpleStringProperty(Usuario);
        this.Contraseña = new SimpleStringProperty(Contraseña);
        this.Pais = new SimpleStringProperty(Pais);
        this.Rol = new SimpleStringProperty(Rol);
    }
    
    public void IngresoUsuarios(String Correo, String Contraseña){
              
        this.Correo = new SimpleStringProperty(Correo);
        
        this.Contraseña = new SimpleStringProperty(Contraseña);
        
               
    }

        
    public String getNombre(){
        return Nombre.get();
    }
    public void setNombre(String Nombre){
        this.Nombre = new SimpleStringProperty(Nombre);
    }
    
    
    public String getCorreo(){
        return Correo.get();
    }
    public void setCorreo(String Correo){
        this.Correo = new SimpleStringProperty(Correo);
    }
    
    
    public String getUsuario(){
        return Usuario.get();
    }
    public void setUsuario(String Usuario){
        this.Usuario = new SimpleStringProperty(Usuario);
    }
    
    
    public String getContraseña(){
        return Contraseña.get();
    }
    public void setContraseña(String Contraseña){
        this.Contraseña = new SimpleStringProperty(Contraseña);
    }
    
    
    public String getPais(){
        return Pais.get();
    }
    public void setPais(String Pais){
        this.Pais = new SimpleStringProperty(Pais);
    }
    
    public String getRol(){
        return Rol.get();
    }
    public void setRol(String Rol){
        this.Rol = new SimpleStringProperty(Rol);
    }
    
    
}