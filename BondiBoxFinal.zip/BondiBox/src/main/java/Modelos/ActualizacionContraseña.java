package Modelos;

import com.google.firebase.auth.FirebaseAuth;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ActualizacionContraseña extends RecursiveTreeObject {

    private StringProperty Correo, Contraseña;

    public ActualizacionContraseña(String Correo, String Contraseña) {
        this.Correo = new SimpleStringProperty(Correo);
        this.Contraseña = new SimpleStringProperty(Contraseña);
    }

    public String getCorreo(){
        return Correo.get();
    }
    public void setCorreo(String Correo){
        this.Correo = new SimpleStringProperty(Correo);
    }
    
    
    public String getContraseña(){
        return Contraseña.get();
    }
    public void setContraseña(String Contraseña){
        this.Contraseña = new SimpleStringProperty(Contraseña);
    }
}
