/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author juanf
 */
public class Contraseñas {
    private StringProperty NombreUsuario, Correo, Pais;

    public Contraseñas(String NombreUsuario, String Correo, String Pais) {
        this.NombreUsuario = new SimpleStringProperty(NombreUsuario);
        this.Correo = new SimpleStringProperty(Correo);
        this.Pais = new SimpleStringProperty(Pais);
    }

    public String getNombreUsuario() {
        return NombreUsuario.get();
    }

    public void setNombreUsuario(String NombreUsuario) {
        this.NombreUsuario = new SimpleStringProperty(NombreUsuario);
    }

    public String getCorreo(){
        return Correo.get();
    }
    public void setCorreo(String Correo){
        this.Correo = new SimpleStringProperty(Correo);
    }

    public String getPais() {
        return Pais.get();
    }

    public void setPais(String Pais) {
        this.Pais =  new SimpleStringProperty(Pais);
    }
    
    
}
